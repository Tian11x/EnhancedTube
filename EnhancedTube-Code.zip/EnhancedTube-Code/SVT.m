function [X] = SVT(Y,rho)
[n1,n2] = size(Y);
max12 = max(n1,n2);
[U,S,V] = svd(Y,'econ');
S = diag(S);
S = max(S-rho,0);
tol = max12*eps(max(S));
r = sum(S > tol);
S = S(1:r);
X = U(:,1:r)*diag(S)*V(:,1:r)';
end

